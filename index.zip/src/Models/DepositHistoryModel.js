// const mongoose = require('mongoose');

// const DepositHistorySchema = new mongoose.Schema({
//   deposit_user_id: mongoose.Schema.Types.ObjectId,
//   transactionID: Number,
//   amount: Number,
//   currency_rate: Number,
//   base_amount: Number,
//   gateway: String,
//   contact_id: mongoose.Schema.Types.ObjectId,
//   agent_id: mongoose.Schema.Types.ObjectId,
//   remark: String,
//   currency: mongoose.Schema.Types.ObjectId,
// });

// module.exports = mongoose.model('DepositHistory', DepositHistorySchema);
