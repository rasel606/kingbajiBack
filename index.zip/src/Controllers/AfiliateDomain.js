// const domainSchema = new mongoose.Schema({
//     domain: String,
//     status: String,
//     keywords: String,
//     page: Number,
//     action: String, // "join", "Sign Up", etc.
// });

// const Domain = mongoose.model('Domain', domainSchema);
// module.exports = Domain 